package core.beans;

public enum CouponType {

	RESTURANS, ELECTRICITY, FOOD, HEALTH, SPORTS,CAMPING, TRAVELLING;
}
