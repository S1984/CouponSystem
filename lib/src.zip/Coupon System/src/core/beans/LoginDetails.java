package core.beans;

public class LoginDetails {

	private long id;
	private boolean loginSuccessful;
	
	
	public LoginDetails(long id, boolean loginSuccessful) {
		super();
		this.id = id;
		this.loginSuccessful = loginSuccessful;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public boolean isLoginSuccessful() {
		return loginSuccessful;
	}
	public void setLoginSuccessful(boolean loginSuccessful) {
		this.loginSuccessful = loginSuccessful;
	}
	
	
}
