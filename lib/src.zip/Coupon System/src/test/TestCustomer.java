package test;

import java.util.Calendar;
import java.util.Date;

import core.Facade.AdminFacade;
import core.Facade.CompanyFacade;
import core.Facade.CustomerFacade;
import core.beans.ClientType;
import core.beans.Company;
import core.beans.Coupon;
import core.beans.CouponType;
import core.beans.Customer;
import core.exceptions.CouponSystemException;
import system.CouponSystem;

public class TestCustomer {

	public static void main(String[] args) {
		CouponSystem system = null;

		Calendar cal = Calendar.getInstance();
		Date startDate = cal.getTime();
		cal.set(2018, Calendar.JANUARY, 20, 0, 0, 0);
		Date endDate1 = cal.getTime();
		cal.set(2018, Calendar.FEBRUARY, 20, 0, 0, 0);
		Date endDate2 = cal.getTime();

		java.sql.Date sd = new java.sql.Date(endDate1.getTime());
		System.out.println(sd );
		
		Coupon coupon1 = new Coupon(1, "BelongToComp11", startDate, endDate1, 2, CouponType.FOOD, "bilong to comp11",
				200, "no iamge");
		Coupon coupon2 = new Coupon(2, "BelongToComp11", startDate, endDate2, 2, CouponType.SPORTS, "bilong to comp11",
				300, "no iamge");
		try {
			system = CouponSystem.getInstance();
//			AdminFacade adminFacade = (AdminFacade) system.login("admin", "1234", ClientType.ADMINISTRATOR);
//			Company comp10 = new Company(1010, "comp10Name", "comp10Pass", "comp10Email");
			Customer cust50 = new Customer(5050, "cust50Name", "cust50pass");
//			Customer cust60 = new Customer(6060, "cust60Name", "cust60pass");

			//adminFacade.createCompany(comp10);
			//adminFacade.createCustomer(cust60);
//			CompanyFacade companyFacade = (CompanyFacade) system.login(comp10.getName(), comp10.getPassword(),
//					ClientType.COMPANY);
			CustomerFacade customerFacade = (CustomerFacade) system.login(cust50.getName(), cust50.getPassword(),
					ClientType.CUSTOMER);

			//companyFacade.createCoupon(coupon1);
			//companyFacade.createCoupon(coupon2);
			//System.out.println("comp10 successful add 2 coupon");

	//		customerFacade.purchaseCoupon(coupon1);
	//		customerFacade.purchaseCoupon(coupon2);
			System.out.println("customer purchased 2 coupons");
			System.out.println("============================");

			System.out.println("show all purchased coupons");
			System.out.println(customerFacade.getAllPurchasedCoupons());
			System.out.println("============================");

			System.out.println("show all purchased under 250$");
			System.out.println(customerFacade.getAllPurchasedCouponsByPrice(250));
			System.out.println("============================");

			System.out.println("show all purchased coupons from sport category");
			System.out.println(customerFacade.getAllPurchasedCouponsByType(CouponType.SPORTS));
			System.out.println("============================");

			System.out.println("Available");
			System.out.println(customerFacade.getAvailableCouponToPurchase());
			System.out.println("============================");

			
			
			//adminFacade.removeCompany(comp10);
			//adminFacade.removeCustomer(cust50);

		} catch (CouponSystemException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				system.shutDown();
			} catch (CouponSystemException e) {
				e.printStackTrace();
			}
		}
	}
}
