package core.dao.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import core.exceptions.CouponSystemException;
import core.exceptions.DuplicateException;
import db.pool.ConnectionPool;

public class SqlCommand {
	
	private static ConnectionPool pool;
	
	private static ConnectionPool getPool() throws CouponSystemException{
		if (pool == null)
		{
			try {
				pool = ConnectionPool.getInstance();
			} catch (SQLException e) {
				CouponSystemException couponSysEx = new CouponSystemException(
						"getPool at SqlCommand Failed to get Instance of pool");
				throw couponSysEx;
			}
		}
		
		 return pool;
	}
	
	
	/**
	 * This Method is used for SQL commands of INSERT.
	 * 
	 * @param sql
	 *            - The sentence we use to execute SQL Commands.
	 * @param pool
	 *            - Gives access to the connection pool.
	 * @param duplicateMessage
	 *            - Custom message build for duplicate Exceptions .
	 * 
	 * @param failedMessage
	 *            - Custom message build for SQL Exceptions
	 * @throws CouponSystemException
	 *             - When you have a duplicate name or id that is not unique or
	 *             in a case of SQL Exceptions.
	 */
	public static void executeUpdateTwoErorMessage(String sql,/* ConnectionPool pool,*/ String duplicateMessage,
			String failedMessage) throws CouponSystemException {
		Connection con = getPool().getConnection();
		try {

			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLIntegrityConstraintViolationException e) {
			DuplicateException duplicateException = new DuplicateException(duplicateMessage + sql);
			throw duplicateException;
		} catch (SQLException e) {
			CouponSystemException couponSysEx = new CouponSystemException(failedMessage + sql);
			throw couponSysEx;
		} finally {
			getPool().returnCon(con);
		}

	}

	/**
	 * This Method is used for SQL commands of UPDATE ,DELETE
	 * 
	 * @param sql
	 *            - The sentence we use to execute SQL Commands.
	 * @param pool
	 *            - Gives access to the connection pool.
	 * @param failedMessage
	 *            - Custom message build for SQL Exceptions
	 * @throws CouponSystemException
	 *             - When you have a case of SQL Exceptions.
	 */
	public static void executeUpdateOneErorMessage(String sql,/* ConnectionPool pool,*/ String failedMessage)
			throws CouponSystemException {

		Connection con = getPool().getConnection();
		try {

			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);

		} catch (SQLException e) {

			CouponSystemException couponSysEx = new CouponSystemException(failedMessage + sql);
			throw couponSysEx;
		} finally {
			getPool().returnCon(con);
		}
	}

	/**
	 * This Method returns a List of arrays,each array represents a
	 * Company,Customer or Coupon. This Method is used for SQL command: SELECT.
	 * 
	 * @param sql
	 *            - The sentence we use to execute SQL Commands.
	 * @param pool
	 *            - Gives access to the connection pool.
	 * @param failedMessage
	 *            - Custom message build for SQL Exceptions
	 * @return A list of arrays - That holds all rows, each row represents a
	 *         Company,Customer or Coupon ,returns null if there is no match.
	 * 
	 * 
	 * @throws CouponSystemException-
	 *             When you have a case of SQL Exceptions.
	 */
	public static List<Object[]> executeQueryOneErorMessage(String sql, /*ConnectionPool pool,*/ String failedMessage)
			throws CouponSystemException {
		Connection con = getPool().getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			List<Object[]> allRows = null;
			if (rs.next() == true) {
				allRows = new ArrayList<>();
				int index = 0;
				do {
					ResultSetMetaData meta = rs.getMetaData();
					int cols = meta.getColumnCount();
					allRows.add(new Object[cols]);
					for (int i = 0; i < allRows.get(index).length; i++) {
						// Array index start from zero
						// _VS_ Sql index start from one
						allRows.get(index)[i] = rs.getObject(i + 1);
					}
					index++;
				} while (rs.next());
			}
			return allRows;
		} catch (SQLException e) {
			CouponSystemException couponSysEx = new CouponSystemException(failedMessage + sql);
			
			throw couponSysEx;
		} finally {
			getPool().returnCon(con);
		}
	}

}
