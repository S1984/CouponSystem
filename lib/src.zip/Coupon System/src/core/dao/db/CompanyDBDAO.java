package core.dao.db;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import core.beans.Company;
import core.beans.LoginDetails;
import core.dao.CompanyDAO;
import core.exceptions.CouponSystemException;

public class CompanyDBDAO implements CompanyDAO {


	public CompanyDBDAO()  {

	}

	/**
	 *  The createCompany method  gets the instance of company.bean and adds it to CompanyTable
	 *  if it fails to create a company it Throws a CouponSystemException. 
	 */
	@Override
	public void createCompany(Company company) throws CouponSystemException {
		String sql = "INSERT INTO Company VALUES(" + company.getId() + ", '" + company.getName() + "', '"
				+ company.getPassword() + "', '" + company.getEmail() + "')";
		String duplicateMessage = "createCompany cancelled, company already exists: ";
		String failedMessage = "createCompany Failed: ";

		SqlCommand.executeUpdateTwoErorMessage(sql, duplicateMessage, failedMessage);
	}

	/**
	 *  The removeCompany method  gets instance of company.bean and deletes it from CompanyTable in case it fails to remove a company, 
	 *   it will Throw a  CouponSystemException. 
	 */
	@Override
	public void removeCompany(Company company) throws CouponSystemException {
		
		String sql = "DELETE FROM Company WHERE id=" + company.getId();
		String failedMessage = "removeCompany Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);
		
		
	}
/**
 * The updateCompany method get instance of company .bean and updates its values (name,password,email) in case it fails to update the company, it will throw a CouponSystemException.  
 */
	@Override
	public void updateCompany(Company company) throws CouponSystemException {
		String sql = "UPDATE Company SET name='" + company.getName() + "', password='" + company.getPassword()
				+ "', email='" + company.getEmail() + "' WHERE id=" + company.getId();
		String failedMessage = "updateCompany Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);

	}
/**
 * the checkIfComanyNameAvailbe method  checks a all companies in the company table according to name 
 * if there is no existing company with the stated name it will return true. 
 * in case there is already a company with the same name it will return false. 
 * In case of failure it will throw CouponSystemException 
 */
	@Override
	public boolean checkIfCompanyNameAvailable(Company company) throws CouponSystemException {
		String sql = "SELECT * from Company WHERE name = '" + company.getName()+"'";
		String failedMessage = "checkIfCompanyNameAvailable Failed: ";
		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);
		if (allRows == null) {
			return true;
		}else{
			return false;
		}	}

	/**
	 * The method getCompany retrieves company object from SQL data. if id  does not exists
	 * return null; Throws CouponSystemException if failed.
	 *  order of entry in company table: 1-id 2-name, 3-password, 4-email
	 *  order of entry in "allRows" start with 0 therefore an entry of email will be 3
	 *  and 0 since we expected only one result
			
	 */
	@Override
	public Company getCompany(long id) throws CouponSystemException {
		String sql = "SELECT * from Company WHERE id=" + id;
		String failedMessage = "getCompany Failed: ";
		Company tempCompany = null;
		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);
		if (allRows != null) {
			
			tempCompany = new Company((Long) allRows.get(0)[0], (String) allRows.get(0)[1], (String) allRows.get(0)[2],
					(String) allRows.get(0)[3]);
		}

		return tempCompany;
	}

	/**
	 * The method getAllCompanies creates a hash set off all companies and returns it; if no
	 * companies exist it will return null.
	 * throws CouponSystemException if it fails. 
	 * Order of entry in company table: 1-id 2-name, 3-password, 4-email.
	 *  order of entry in allRows start with 0 therefore an entry of name will be  position 1 in "allCompanies"
	 *  
	 * 
	 */
	@Override
	public Collection<Company> getAllCompanies() throws CouponSystemException {
		Collection<Company> allCompanies = null;
		String sql = "SELECT * from Company";
		String failedMessage = "getAllCompanies Failed: ";
		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);

		if (allRows != null) {
			allCompanies = new HashSet<>();
			for (Object[] objects : allRows) {
			
				allCompanies.add(
						new Company((Long) objects[0], (String) objects[1], (String) objects[2], (String) objects[3]));
			}
		}
		return allCompanies;
	}


	/**
	 * The method Login details Searches the data base for the company's name,
	 * if  the name does not exist it will return false otherwise it will compare the given password and return true or false.
	 * In company table: 1-id 2-name, 3-password, 4-email
	 * In the  array: 0-id 1-name, 2-password,  3-email
	 * in this case we use only row 0 because we are expecting only one result ;
	 */
	@Override
	public LoginDetails login(String name, String password) throws CouponSystemException {
		String sql = "SELECT * from Company WHERE name= '" + name + "' ";
		String failedMessage = "login company Failed: ";
		LoginDetails loginDetails = new LoginDetails(-1, false);
		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);
		
		if (allRows != null) {
			String dbPassword = (String) allRows.get(0)[2];
			if (dbPassword.equals(password)) {
				loginDetails.setLoginSuccessful(true);
				loginDetails.setId((Long)allRows.get(0)[0]);
				
			}
		}
		return loginDetails;

	}

}
