package core.Facade;

public class CouponClientFacade {

}
