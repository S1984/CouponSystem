package system;

import java.sql.SQLException;

import core.Facade.AdminFacade;
import core.Facade.CompanyFacade;
import core.Facade.CouponClientFacade;
import core.Facade.CustomerFacade;
import core.beans.ClientType;
import core.beans.LoginDetails;
import core.dao.CompanyDAO;
import core.dao.CustomerDAO;
import core.dao.db.CompanyDBDAO;
import core.dao.db.CustomerDBDAO;
import core.exceptions.CouponSystemException;
import core.thread.DailyCouponExpirationTask;
import db.pool.ConnectionPool;

public class CouponSystem {

	private static CouponSystem instance = null;
	private CompanyDAO companydbdao;
	private CustomerDAO customerdbdao;
	private DailyCouponExpirationTask couponExpirationTask;
	private Thread dailyTask;

	public CouponSystem() throws CouponSystemException {
		companydbdao = new CompanyDBDAO();
		customerdbdao = new CustomerDBDAO();
		couponExpirationTask = new DailyCouponExpirationTask();
		dailyTask = new Thread(couponExpirationTask);
		dailyTask.start();

	}

	/**
	 * The method getInstance returns a signaltone of couponSystem if its not the first time it will return instance of an object if it is the first time it creates a new instance.
	 * @return instance if exists if not it creates a new one.
	 * @throws CouponSystemException -from DBDAO
	 */
	public static CouponSystem getInstance() throws CouponSystemException {
		if (instance == null) {
			instance = new CouponSystem();
		}
		return instance;
	}

	/**
	 * The method login checks if login was made successfully and returns client facade.
	 * @param name 
	 * @param password
	 * @param clientType: CUSTOMER, COMPANY, ADMINISTRATOR
	 * @return  Coupon client facade 
	 * @throws CouponSystemException if login failed and from DBDAO
	 */
	
	public CouponClientFacade login(String name, String password, ClientType clientType) throws CouponSystemException {
		LoginDetails loginDetails;
		CouponSystemException couponSysEx;
		switch (clientType) {

		case CUSTOMER:
			loginDetails = customerdbdao.login(name, password);
			if (loginDetails.isLoginSuccessful()) {
				return new CustomerFacade(customerdbdao.getCustomer(loginDetails.getId()));
			} else {
				couponSysEx = new CouponSystemException(
						"Client type: CUSTOMER, Failed to login, name: " + name + ", password: " + password);
			}
			break;
		case COMPANY:
			loginDetails = companydbdao.login(name, password);
			if (loginDetails.isLoginSuccessful()){
				return new CompanyFacade(companydbdao.getCompany(loginDetails.getId()));
			}else{
				couponSysEx = new CouponSystemException(
						"Client type: COMPANY, Failed to login, name: " + name + ", password: " + password);
			}
			break;
		case ADMINISTRATOR:
			if (name.equals("admin") && password.equals("1234")){
				return new AdminFacade();
			}else{
				couponSysEx = new CouponSystemException(
						"Client type: ADMINISTRATOR, Failed to login, name: " + name + ", password: " + password);
			}
			break;
			default:
				couponSysEx = new CouponSystemException(
						"Client type: Undefined, Failed to login, name: " + name + ", password: " + password);
		}
		throw couponSysEx;
	}

	/**
	 * The method shutDown shut downs all connections and daily task
	 * 
	 * @throws CouponSystemException - an SQL Exception.
	 */
	public void shutDown() throws CouponSystemException {
		couponExpirationTask.StopTheTask();
		dailyTask.interrupt();
		try {
			dailyTask.join();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			ConnectionPool.getInstance().closeAllConnections();
		} catch (SQLException e) {
			CouponSystemException couponSysEx = new CouponSystemException("shutDown Failed to close all connections");
			
			throw couponSysEx;

		}
	}
}
