package core.dao;

import core.beans.Company;
import core.beans.Coupon;
import core.exceptions.CouponSystemException;

public interface CompanyCouponDAO {

	
	/**
	 * The insertCouppon method inserts company id and coupon id and inserts them into the company_coupon table
	 * @param company 
	 * @param coupon
	 * @throws CouponSystemException -in case of SQL Exception.
	 */
	void insertCoupon(Company company, Coupon coupon) throws CouponSystemException;
	
	/**
	 * The removeCoupon method deletes  coupon from company_coupn table
	 * @param coupon
	 * @throws CouponSystemException -in case of SQL Exception.
	 */
	void removeCoupon(Coupon coupon)throws CouponSystemException;
	
	/**
	 * the removeAllCompanyCoupons removes all the coupons from company_coupon table 
	 * @param company
	 * @throws CouponSystemException -in case of SQL Exception.
	 */
	void removeAllCompanyCoupons(Company company) throws CouponSystemException;
	
	/**
	 * the checkIfCouponBelongToCompany  checks if coupon belongs to the company.
	 * @param company
	 * @param coupon
	 * @return true or false
	 * @throws CouponSystemException -in case of SQL Exception.
	 */
	boolean checkIfCouponBelongToCompany (Company company, Coupon coupon) throws CouponSystemException;
}
