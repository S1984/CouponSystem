package core.beans;

public enum ClientType {
	CUSTOMER, COMPANY, ADMINISTRATOR;
}
