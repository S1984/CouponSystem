package core.dao.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import core.beans.Company;
import core.beans.Coupon;
import core.beans.CouponType;
import core.beans.Customer;
import core.dao.CouponDAO;
import core.exceptions.CouponSystemException;
import db.pool.ConnectionPool;

public class CouponDBDAO implements CouponDAO {

	private ConnectionPool pool;

	public CouponDBDAO() throws CouponSystemException {

		try {
			pool = ConnectionPool.getInstance();
		} catch (SQLException e) {
			CouponSystemException couponSysEx = new CouponSystemException(
					"getPool at SqlCommand Failed to get Instance of pool");
			throw couponSysEx;
		}
	}

	/**
	 * The createCoupon method gets the instance of Coupon.bean and adds it to
	 * Coupon Table if it fails to create a company it Throws a
	 * CouponSystemException.
	 */
	@Override
	public void createCoupon(Coupon coupon) throws CouponSystemException {

		String insertInto = "insert into Coupon VALUES(?,?,?,?,?,?,?,?,?)";
		String duplicateMessage = "createCoupon cancelled, coupon already exists: id - ";
		String failedMessage = "createCoupon Failed: ";

		executeUpdatePreStmtCoupon(coupon, insertInto, duplicateMessage, failedMessage);
	}

	/**
	 * The removeCoupon method gets instance of Coupon.bean and deletes the
	 * coupon from CouponTable in case it fails to remove a coupon, it will
	 * Throw a CouponSystemException.
	 */
	@Override
	public void removeCoupon(Coupon coupon) throws CouponSystemException {
		String sql = "DELETE FROM Coupon WHERE id=" + coupon.getId();
		String failedMessage = "removeCoupon Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);
	}

	/**
	 * The updateCoupon method get instance of coupon.bean and updates its
	 * values (id,title,start_date,end_date,amount,type,message,price and image)
	 * in case it fails to update the company, it will throw a
	 * CouponSystemException.
	 */
	@Override
	public void updateCoupon(Coupon coupon) throws CouponSystemException {

		String updateStmt = "UPDATE Coupon SET id= ?, title= ?, start_date= ?, end_date= ?, amount= ?, type= ?, message= ?, price= ?, image= ? WHERE id="
				+ coupon.getId();
		String failedMessage = "updateCoupon Failed: ";
		executeUpdatePreStmtCoupon(coupon, updateStmt, null, failedMessage);

	}

	/**
	 * The method getCompany retrieves company object from SQL data. if id does
	 * not exists return null; Throws CouponSystemException if failed. order of
	 * entry in company table: 1-id, 2- title, 3- startDate, 4- endDate, 5-
	 * amount, 6- type, 7- message,8- price, 9- image order of entry in
	 * "allRows" start with 0 therefore an entry of endDate will be 3 in this
	 * case we will only use row 0.
	 * 
	 */
	@Override
	public Coupon getCoupon(long id) throws CouponSystemException {
		String sql = "SELECT * from Coupon WHERE id=" + id;
		String failedMessage = "getCoupon Failed: ";
		Coupon tempCoupon = null;

		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);
		if (allRows != null) {

			tempCoupon = new Coupon((Long) allRows.get(0)[0], (String) allRows.get(0)[1], (Date) allRows.get(0)[2],
					(Date) allRows.get(0)[3], (Integer) allRows.get(0)[4],
					CouponType.valueOf((String) allRows.get(0)[5]), (String) allRows.get(0)[6],
					(Double) allRows.get(0)[7], (String) allRows.get(0)[8]);
		}

		return tempCoupon;
	}

	/**
	 * The method getAllCoupon returns a collection off all coupons in coupon
	 * table.
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	@Override
	public Collection<Coupon> getAllCoupon() throws CouponSystemException {
		String sql = "SELECT * from Coupon";
		String failedMessage = "getAllCoupon Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCouponByType returns a collection off all coupons by a
	 * given type in coupon table.
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	@Override
	public Collection<Coupon> getCouponByType(CouponType coupontype) throws CouponSystemException {
		String sql = "SELECT * from Coupon WHERE type= '" + coupontype.name() + "'";
		String failedMessage = "getCouponByType Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);

	}

	/**
	 * The method getCouponByDateLimit returns a collection off all coupons
	 * until a certain end_date in coupon table.
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	@Override
	public Collection<Coupon> getCouponByDateLimit(java.util.Date dateLimit) throws CouponSystemException {
		Date sqldateLimit = new Date(dateLimit.getTime());
		String sql = "SELECT * from Coupon WHERE Coupon.end_date <= '" + sqldateLimit + "'";
		String failedMessage = "getCouponByCompanyAndDateLimit Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCouponByCompany returns a collection of coupons by a
	 * certain company_id in coupon table and Company_Coupon.
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	@Override
	public Collection<Coupon> getCouponByCompany(Company company) throws CouponSystemException {
		String sql = "SELECT * FROM Coupon INNER JOIN Company_Coupon ON Coupon.id=Company_Coupon.coupon_id WHERE company_id= "
				+ company.getId();
		String failedMessage = "getCouponByCompany Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCouponByCompanyAndPriceLimit returns a collection of
	 * coupons from coupon table by a certain company_id in company_Coupon table
	 * and price from coupon table .
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	//update 30.09 before<   after<=
	@Override
	public Collection<Coupon> getCouponByCompanyAndPriceLimit(Company company, double price)
			throws CouponSystemException {
		String sql = "SELECT * FROM Coupon INNER JOIN Company_Coupon ON Coupon.id=Company_Coupon.coupon_id WHERE Company_Coupon.company_id= "
				+ company.getId() + " AND Coupon.price<= " + price;
		String failedMessage = "getCouponByCompanyAndPriceLimit Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCouponByCompanyAndDateLimit returns a collection of coupons
	 * from coupon table by a certain company_id in company_Coupon table and
	 * end_date from coupon table .
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	//updated on 13/10/2017
	@Override
	public Collection<Coupon> getCouponByCompanyAndDateLimit(Company company, java.util.Date dateLimit)
			throws CouponSystemException {
		Date sqldateLimit = new Date(dateLimit.getTime());
		String sql = "SELECT * FROM Coupon INNER JOIN Company_Coupon ON Coupon.id=Company_Coupon.coupon_id WHERE Company_Coupon.company_id= "
				+ company.getId() + " AND Coupon.end_date >= '" + sqldateLimit + "' AND Coupon.start_date <= '" + sqldateLimit + "'";
		String failedMessage = "getCouponByCompanyAndDateLimit Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCouponByCompanyAndType returns a collection of coupons from
	 * coupon table by a certain company_id in company_Coupon table and
	 * coupon_type from coupon table .
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	@Override
	public Collection<Coupon> getCouponByCompanyAndType(Company company, CouponType coupontype)
			throws CouponSystemException {
		String sql = "SELECT * FROM Coupon INNER JOIN Company_Coupon ON Coupon.id=Company_Coupon.coupon_id WHERE Company_Coupon.company_id= "
				+ company.getId() + " AND Coupon.type= '" + coupontype.name() + "'";
		String failedMessage = "getCouponByCompanyAndType Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCouponByCustomer returns a collection of coupons from
	 * coupon table by a certain customer_id in coupon table .
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	@Override
	public Collection<Coupon> getCouponByCustomer(Customer customer) throws CouponSystemException {

		String sql = "SELECT * FROM Coupon INNER JOIN Customer_Coupon ON Coupon.id=Customer_Coupon.coupon_id WHERE customer_id= "
				+ customer.getId();
		String failedMessage = "getCouponByCustomer Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	// add 30.09 for Purchase Coupon
	//edited at 15.10.2017
	public Collection<Coupon> getAvailableCouponToPurchase(Customer customer) throws CouponSystemException {
		Date sqldateLimit = new Date(Calendar.getInstance().getTimeInMillis());
		
		String sql = "SELECT * FROM coupon c WHERE NOT EXISTS (SELECT * FROM   customer_coupon cc WHERE  c.id = cc.coupon_id AND  cc.customer_id ="+ customer.getId() 
		+ ") AND c.amount > 0 AND c.end_date >= '" + sqldateLimit + "'" + "AND c.start_date <= '" + sqldateLimit + "'";
		
		String failedMessage = "getAvailableCouponToPurchase Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCouponByCustomerAndPriceLimit returns a collection of
	 * coupons from coupon table by a certain customer_id in customer_Coupon
	 * table and price from coupon table .
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	//update 30.09 before<   after<=
	@Override
	public Collection<Coupon> getCouponByCustomerAndPriceLimit(Customer customer, double price)
			throws CouponSystemException {
		String sql = "SELECT * FROM Coupon INNER JOIN Customer_Coupon ON Coupon.id=Customer_Coupon.coupon_id WHERE Customer_Coupon.customer_id= "
				+ customer.getId() + " AND Coupon.price<= " + price;
		String failedMessage = "getCouponByCustomerAndPriceLimit Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCouponByCustomerAndType returns a collection of coupons
	 * from coupon table by a certain customer_id in customer_Coupon table and
	 * coupon_type from coupon table .
	 * 
	 * Throws CouponSystemException if it fails.
	 */
	@Override
	public Collection<Coupon> getCouponByCustomerAndType(Customer customer, CouponType coupontype)
			throws CouponSystemException {
		String sql = "SELECT * FROM Coupon INNER JOIN Customer_Coupon ON Coupon.id=Customer_Coupon.coupon_id WHERE Customer_Coupon.customer_id= "
				+ customer.getId() + " AND Coupon.type= '" + coupontype.name() + "'";
		String failedMessage = "getCouponByCustomerAndType Failed: ";
		return getCollectionOfCouponByCondition(sql, failedMessage);
	}

	/**
	 * The method getCollectionOfCouponByCondition returns a hash set off all
	 * coupons by a condition and returns it; if no coupons exist it will return
	 * null. throws CouponSystemException if it fails. Order of entry in at
	 * Coupon table: 1-id, 2- title, 3- startDate, 4- endDate, 5- amount, 6-
	 * type, 7- message,8- price, 9- image. order of entry in "allCoupons" start
	 * with 0 therefore an entry of title will be position 1 .
	 * 
	 * 
	 */
	private Collection<Coupon> getCollectionOfCouponByCondition(String sql, String failedMessage)
			throws CouponSystemException {
		Collection<Coupon> allCoupons = null;

		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);

		if (allRows != null) {
			allCoupons = new HashSet<>();
			for (Object[] objects : allRows) {

				allCoupons.add(new Coupon((Long) objects[0], (String) objects[1], (Date) objects[2], (Date) objects[3],
						(Integer) objects[4], CouponType.valueOf((String) objects[5]), (String) objects[6],
						(Double) objects[7], (String) objects[8]));
			}
		}

		return allCoupons;
	}

	/**
	 * This method is used for SQL commands as prepared statements to be used in
	 * other methods to insert coupon information to the coupon table ( such as
	 * INSERT,UPDATE )
	 * 
	 * @param coupon
	 *            - the coupon we are interested to UPDATE or INSERT in the DB
	 * @param statementStr
	 *            - SQL prepared statement to execute.
	 * @param duplicateMessage
	 *            - Custom message build for duplicate Exceptions .
	 * @param failedMessage
	 *            - Custom message build for SQL Exceptions
	 * @throws CouponSystemException
	 *             - When you have a case of SQL Exceptions.
	 */
	private void executeUpdatePreStmtCoupon(Coupon coupon, String statementStr, String duplicateMessage,
			String failedMessage) throws CouponSystemException {
		Connection con = pool.getConnection();

		try {
			PreparedStatement preStmt = con.prepareStatement(statementStr);
			preStmt.setLong(1, coupon.getId());
			preStmt.setString(2, coupon.getTitle());
			preStmt.setDate(3, new Date(coupon.getStartDate().getTime()));
			preStmt.setDate(4, new Date(coupon.getEndDate().getTime()));
			preStmt.setInt(5, coupon.getAmount());
			preStmt.setString(6, coupon.getType().name());
			preStmt.setString(7, coupon.getMessage());
			preStmt.setDouble(8, coupon.getPrice());
			preStmt.setString(9, coupon.getImage());
			preStmt.executeUpdate();
		} catch (SQLIntegrityConstraintViolationException e) {
			if (duplicateMessage == null) { // this Exception use only for
											// createCoupon
				duplicateMessage = "this Exception throw from updateCoupon, something went wrong if you get this message";
			}
			CouponSystemException couponSysEx = new CouponSystemException(duplicateMessage + coupon.getId());

			throw couponSysEx;
		} catch (SQLException e) {
			CouponSystemException couponSysEx = new CouponSystemException(failedMessage + coupon.getId());

			throw couponSysEx;
		} finally {
			pool.returnCon(con);
		}
	}

}
