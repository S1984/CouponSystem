package core.dao.db;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import core.beans.Customer;
import core.beans.LoginDetails;
import core.dao.CustomerDAO;
import core.exceptions.CouponSystemException;

public class CustomerDBDAO implements CustomerDAO {


	public CustomerDBDAO() {
		
	}
	/**
	 * the checkIfCustomerNameAvailable method  checks a all customers in the customer table according to name 
	 * if there is no existing customer with the same name it will return true. 
	 * in case there is already a customer with the same name it will return false. 
	 * In case of failure it will throw CouponSystemException 
	 */
	@Override
	public boolean checkIfCustomerNameAvailable (Customer customer) throws CouponSystemException{
		String sql = "SELECT * from Customer WHERE name = '" + customer.getName()+"'";
		String failedMessage = "checkIfCustomerNameAvailable Failed: ";
		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);
		if (allRows == null) {
			return true;
		}else{
			return false;
		}
	}
	/**
	 *  The createCustomer method  gets the instance of customer.bean and adds it to Customer Table with id,name and password.
	 *  if it fails to create a customer it Throws a CouponSystemException. 
	 */
	@Override
	public void createCustomer(Customer customer) throws CouponSystemException {
		// Customer(long id, String name, String password)
		String sql = "INSERT INTO Customer VALUES(" + customer.getId() + ", '" + customer.getName() + "', '"
				+ customer.getPassword() + "')";
		String duplicateMessage = "createCustomer cancelled, customer name and id must to be uniqe): ";
		String failedMessage = "createCustomer Failed: ";

		SqlCommand.executeUpdateTwoErorMessage(sql, duplicateMessage, failedMessage);

	}
	/**
	 *  The removeCustomer method  gets customer id and deletes the customer from the Customer Table in case it fails to remove a customer, 
	 *   it will Throw a  CouponSystemException. 
	 */
	@Override
	public void removeCustomer(Customer customer) throws CouponSystemException {
		String sql = "DELETE FROM Customer WHERE id=" + customer.getId();
		String failedMessage = "removeCustomer Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);
	}
	/**
	 * The updateCustomer method get  customer id  and updates the customers values (name,password,id) in case it fails to update the customer, it will throw a CouponSystemException.  
	 */
	@Override
	public void updateCustomer(Customer customer) throws CouponSystemException {
		String sql = "UPDATE Customer SET name='" + customer.getName() + "', password='" + customer.getPassword()
				+ "' WHERE id=" + customer.getId();
		String failedMessage = "updateCustomer Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);
	}

	/**
	 * The method getCustomer retrieves customer object from SQL data. if id  does not exists
	 * it will return null; Throws CouponSystemException if failed.
	 *  order of entry in Customer table: 1-id 2-name, 3-password
	 *  order of entry in at array: 0-id 1-name, 2-password
	 *  in this case we are only using row 0 because we expecting just one result ;
			
	 */
	@Override
	public Customer getCustomer(long id) throws CouponSystemException {
		String sql = "SELECT * from Customer WHERE id=" + id;
		String failedMessage = "getCustomer Failed: ";
		Customer tempCustomer = null;
		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);
		if (allRows != null) {
			
			tempCustomer = new Customer((Long) allRows.get(0)[0], (String) allRows.get(0)[1],
					(String) allRows.get(0)[2]);
		}
		return tempCustomer;
	}
	/**
	 * The method getAllCustomer creates a hash set off all customers and returns it; if no
	 * customers exist it will return null.
	 * throws CouponSystemException if it fails. 
	 * Order of entry in Customer table: 1-id 2-name, 3-password, 4-email
	 *  order of entry in allCustomers start with 0 therefore an entry of name will be  position 1.
	 *  
	 * 
	 */
	@Override
	public Collection<Customer> getAllCustomer() throws CouponSystemException {
		Collection<Customer> allCustomers = null;
		String sql = "SELECT * from Customer";
		String failedMessage = "getAllCustomer Failed: ";
		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);

		if (allRows != null) {
			allCustomers = new HashSet<>();
			for (Object[] objects : allRows) {
				// at Customer table: 1-id 2-name, 3-password, 4-email
				allCustomers.add(new Customer((Long) objects[0], (String) objects[1], (String) objects[2]));
			}
		}
		return allCustomers;
	}

	

	/**
	 * The method Login details Searches the data base for the customers name,
	 * if  the name does not exist it will return false otherwise it will compare the given password and return true or false.
	 * In Customer table: 1-id 2-name, 3-password
	 * In the  array: 0-id 1-name, 2-password
	 * in this case we use only row 0 because we are expecting only one result ;
	 */

	@Override
	public LoginDetails login(String name, String password) throws CouponSystemException {
		String sql = "SELECT * from Customer WHERE name= '" + name + "' ";
		String failedMessage = "login customer Failed: ";
		LoginDetails loginDetails = new LoginDetails(-1, false);
		List<Object[]> allRows = SqlCommand.executeQueryOneErorMessage(sql, failedMessage);
		// at Customer table: 1-id 2-name, 3-password
		// at array: 0-id 1-name, 2-password
		// in this case we use only row 0 because we expect for one result ;
		if (allRows != null) {
			String dbPassword = (String) allRows.get(0)[2];
			if (dbPassword.equals(password)) {
				loginDetails.setLoginSuccessful(true);
				loginDetails.setId((Long)allRows.get(0)[0]);
				
			}
		}
		return loginDetails;
	}

}
