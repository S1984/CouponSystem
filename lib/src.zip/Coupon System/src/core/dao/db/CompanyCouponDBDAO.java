package core.dao.db;

import core.beans.Company;
import core.beans.Coupon;
import core.dao.CompanyCouponDAO;
import core.exceptions.CouponSystemException;

public class CompanyCouponDBDAO implements CompanyCouponDAO {


	public CompanyCouponDBDAO() {
	}
	/**
	 *  The insertCouppon method  gets the instance of company.bean and coupon.bean and inserts it into a row in Company_Coupon table
	 *  if it fails to insert a coupon it Throws a CouponSystemException. 
	 *  
	 */
	@Override
	public void insertCoupon(Company company, Coupon coupon) throws CouponSystemException {
		String sql = "INSERT INTO Company_Coupon VALUES(" + company.getId() + ", " + coupon.getId() + ")";
		String duplicateMessage = "insertCoupon cancelled, coupon id already exists: ";
		String failedMessage = "insertCoupon Failed: ";

		SqlCommand.executeUpdateTwoErorMessage(sql, duplicateMessage, failedMessage);
	}
	/**
	 *  The removeCoupon method  gets instance of coupon.bean and deletes it and company_id from Company_Coupon table in case it fails to remove a company, 
	 *  it  will Throw a  CouponSystemException. 
	 */
	@Override
	public void removeCoupon(Coupon coupon) throws CouponSystemException {
		String sql = "DELETE FROM Company_Coupon WHERE coupon_id=" + coupon.getId();
		String failedMessage = "removeCoupon Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);
	}

	/**
	 *  The removeAllCompanyCoupons method  gets company and deletes all of their coupon from Company_Coupon table.
	 *   in case it fails to remove, 
	 *  it  will Throw a  CouponSystemException. 
	 */
	@Override
	public void removeAllCompanyCoupons(Company company) throws CouponSystemException {
		String sql = "DELETE FROM Company_Coupon WHERE company_id=" + company.getId();
		String failedMessage = "removeAllCompanyCoupons Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);
	}
	/**
	 * The checkIfCouponBelongToCompany method checks  if coupon belongs to company.
	 * if it does find both values it will return false otherwise it will return true.
	 * in case it fails it throws CouponSystemException.
	 */
	@Override
	public boolean checkIfCouponBelongToCompany (Company company, Coupon coupon) throws CouponSystemException {
		String sql = "SELECT * from Company_Coupon WHERE company_id= " + company.getId() + " AND coupon_id= "+coupon.getId();
		String failedMessage = "checkIfCouponBelongToCompany Failed: ";
		if(null==SqlCommand.executeQueryOneErorMessage(sql, failedMessage))
			return false;
		else
			return true;
	}
}
