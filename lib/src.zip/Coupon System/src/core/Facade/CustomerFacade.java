package core.Facade;

import java.util.Collection;
import java.util.Date;

import core.beans.Coupon;
import core.beans.CouponType;
import core.beans.Customer;
import core.dao.CouponDAO;
import core.dao.CustomerCouponDAO;
import core.dao.db.CouponDBDAO;
import core.dao.db.CustomerCouponDBDAO;
import core.exceptions.CouponSystemException;
import core.exceptions.FacadeException;

public class CustomerFacade extends CouponClientFacade {

	private Customer customer;
	private CouponDAO coupondbdao;
	private CustomerCouponDAO customercoupondbdao;

	public CustomerFacade(Customer customer) throws CouponSystemException {
		this.customer = customer;
		coupondbdao = new CouponDBDAO();
		customercoupondbdao = new CustomerCouponDBDAO();

	}

	/**
	 * The method purchaseCoupon adds a coupon to customer_coupon table 
	 *  if it is  the first purchase of this coupon, then execute and update coupon amount -1.
	 * addCustomerCoupon with customer details and coupon details.
	 * 
	 * @param coupon
	 * @throws CouponSystemException -from DBDAO.
	 * @throws facadeexception
	 *              if Coupon cannot be purchased. Coupons could be out of stock
	 *              ,out dated or not within the valid dates of the sale or the customer 
	 *              already purchased this coupon.
	 */
	public void purchaseCoupon(Coupon coupon) throws CouponSystemException {
		Coupon couponFromDB = coupondbdao.getCoupon(coupon.getId());
		FacadeException facadeexception = null;
		if(couponFromDB==null)
		{
			facadeexception = new FacadeException(
					"purchaseCoupon in Customer facade cancelled, coupon not exsits");
			throw facadeexception;
		}
		Date now = new Date();
		// need to be greater then zero
		boolean flagStart = 0 < now.compareTo(couponFromDB.getStartDate());
		// need to be lees then zero
		boolean flagEnd = 0 > now.compareTo(couponFromDB.getEndDate());
		
		if (customercoupondbdao.checkIfCouponAlreadyAdded(this.customer, couponFromDB)) {
			facadeexception = new FacadeException(
					"purchaseCoupon in Customer facade cancelled, You cannot purchase the same coupon twice");
			throw facadeexception;
		}
		if (0 < couponFromDB.getAmount() && flagStart && flagEnd) {
			customercoupondbdao.addCustomerCoupon(this.customer, couponFromDB);
			couponFromDB.setAmount(couponFromDB.getAmount() - 1);
			coupondbdao.updateCoupon(couponFromDB);
		} else {
			facadeexception = new FacadeException(
					"purchaseCoupon in Customer facade Failed , coupon cnnot be  purchased!" + "\n" + "amount: "
							+ couponFromDB.getAmount() + ", coupon not within the valid dates of the sale: " + !flagStart
							+ ", coupon expired: " + !flagEnd);
			throw facadeexception;
		}

	}
/**
 * the method getallPurchasedCoupons retrieves a collection of all coupons by a certian customer 
 * @return coupon by customer.
 * @throws CouponSystemException -from DBDAO.
 */
	public Collection<Coupon> getAllPurchasedCoupons() throws CouponSystemException {
		return coupondbdao.getCouponByCustomer(this.customer);
	}
/**
 * The method getallPurchasedCouponsByType retrieves a collection of coupons by a certain customer and type.
 * @param coupontype
 * @return coupon by customer and type.
 * @throws CouponSystemException -from DBDAO.
 */
	public Collection<Coupon> getAllPurchasedCouponsByType(CouponType coupontype) throws CouponSystemException {
		return coupondbdao.getCouponByCustomerAndType(this.customer, coupontype);
	}
/**
 *  The method getAllPurchasedCouponsByPrice retrieves a collection of customers coupons by a price limit
 * @param priceLimit
 * @return coupon by customer and price limit
 * @throws CouponSystemException -from DBDAO.
 */
	public Collection<Coupon> getAllPurchasedCouponsByPrice(double priceLimit) throws CouponSystemException {
		return coupondbdao.getCouponByCustomerAndPriceLimit(this.customer, priceLimit);
	}
	/**
	 * added date 27.08.2017 updated with new method at 30.09
	 * @return
	 * @throws CouponSystemException
	 */
	public Collection<Coupon> getAvailableCouponToPurchase () throws CouponSystemException {
		return coupondbdao.getAvailableCouponToPurchase(customer);
				}

	// add 30.09 for welcome page
	public String getCustomerName (){
		return this.customer.getName();
	}
		
	}

