package core.dao;

import java.util.Collection;
import java.util.Date;

import core.beans.Company;
import core.beans.Coupon;
import core.beans.CouponType;
import core.beans.Customer;
import core.exceptions.CouponSystemException;

public interface CouponDAO {

	/**
	 * The method createCoupon creates a coupon in the coupon table
	 * 
	 * @param coupon
	 * @throws CouponSystemException
	 *             -in case of SQL Exception or duplicate unique id.
	 */
	void createCoupon(Coupon coupon) throws CouponSystemException;

	/**
	 * The method removeCoupon removes a coupon from coupon table.
	 * 
	 * @param coupon
	 * @throws CouponSystemException
	 *             -in case of SQL Exception. 
	 */
	void removeCoupon(Coupon coupon) throws CouponSystemException;

	/**
	 * The method updateCoupon updates all coupon details in the coupon table
	 * 
	 * @param coupon
	 * @throws CouponSystemException
	 *             -in case of SQL Exception duplicate unique id
	 */
	void updateCoupon(Coupon coupon) throws CouponSystemException;

	/**
	 * The method getCoupon retrieves the coupon from coupon table by using
	 * coupon id
	 * 
	 * @param id
	 * @return coupon by id or null if not found
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Coupon getCoupon(long id) throws CouponSystemException;

	/**
	 * the method getAllCoupons retrieves a collection of all coupons from
	 * coupons table.
	 * 
	 * @return collection of all coupons or null.
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getAllCoupon() throws CouponSystemException;

	/**
	 * the method GetCouponsByType retrieves a collection of coupons from
	 * coupons table with the same type.
	 * 
	 * @param coupontype
	 * @return collection of coupons by type or null.
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getCouponByType(CouponType coupontype) throws CouponSystemException;

	/**
	 * The method getCouponByDateLimit retrieves a collection of coupons from
	 * coupons table with the same end_date
	 * 
	 * @param dateLimit
	 * @return collection of coupons by end_date or null.
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getCouponByDateLimit(Date dateLimit) throws CouponSystemException;

	/**
	 * The method getCouponByCompany retrieves a collection of coupons from
	 * coupon table that belongs to the company.
	 * 
	 * @param company
	 * @return collection of coupons that belong to the company or null.
	 * @throws CouponSystem-in
	 *             case of SQL Exception
	 */
	Collection<Coupon> getCouponByCompany(Company company) throws CouponSystemException;

	/**
	 * The method getCouponByCompanyAndPriceLimit retrieves a collection of
	 * coupons from coupon table that belongs to the company and with a price
	 * limit.
	 * 
	 * @param company
	 * @param price
	 * @return collection of coupons by company and price limit or null.
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getCouponByCompanyAndPriceLimit(Company company, double price) throws CouponSystemException;

	/**
	 * The method getCouponByCompanyAndDateLimit retrieves a collection of
	 * coupons from coupon table that belongs to the company and with a
	 * end_date.
	 * 
	 * @param company
	 * @param dateLimit
	 * @return collection of coupons by company and end_date or null.
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getCouponByCompanyAndDateLimit(Company company, Date dateLimit) throws CouponSystemException;

	/**
	 * The method getCouponByCompanyAndType retrieves a collection of coupons
	 * from coupon table that belongs to the company and type.
	 * 
	 * @param company
	 * @param coupontype
	 * @return collection of coupons by company and type or null.
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getCouponByCompanyAndType(Company company, CouponType coupontype) throws CouponSystemException;

	/**
	 * The method getCouponByCustomer retrieves a collection of coupons from
	 * coupon table that belongs to the customer.
	 * 
	 * @param customer
	 * @return collection of coupons by customer or null
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getCouponByCustomer(Customer customer) throws CouponSystemException;

	/**
	 * The method getCouponByCustomerAndPriceLimit retrieves a collection of
	 * coupons from coupon table that belongs to the customer and price limit.
	 * 
	 * @param customer
	 * @param price
	 * @return coupon collection by customer and price limit or null
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getCouponByCustomerAndPriceLimit(Customer customer, double price) throws CouponSystemException;

	/**
	 * The method getCouponByCustomerAndType retrieves a collection of coupons
	 * from coupon table that belongs to the customer and type.
	 * 
	 * @param customer
	 * @param coupontype
	 * @return coupon collection by customer and type or null.
	 * @throws CouponSystemException
	 *             -in case of SQL Exception
	 */
	Collection<Coupon> getCouponByCustomerAndType(Customer customer, CouponType coupontype)
			throws CouponSystemException;

	// add 30.09 for Purchase Coupon
	Collection<Coupon> getAvailableCouponToPurchase(Customer customer) throws CouponSystemException ;
	
	
}
