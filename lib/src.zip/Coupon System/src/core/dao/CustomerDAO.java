package core.dao;

import java.util.Collection;


import core.beans.Customer;
import core.beans.LoginDetails;
import core.exceptions.CouponSystemException;

public interface CustomerDAO {

	/**
	 * The method createCustomer creates a new customer in the customer table.
	 * @param customer
	 * @throws CouponSystemException -in case of SQL Exception or duplicate unique name and id
	 */
	void createCustomer(Customer customer) throws CouponSystemException;

	/**
	 * The method removeCustomer deletes a customer from customer company.
	 * @param customer
	 * @throws CouponSystemException -in case of SQL Exception.
	 */
	void removeCustomer(Customer customer) throws CouponSystemException;

	/**
	 * The method updateCustomer updates a customer details in the customer table.
	 * @param customer
	 * @throws CouponSystemException -in case of SQL Exception or duplicate unique name and id.
	 */
	void updateCustomer(Customer customer) throws CouponSystemException;
	
	/**
	 * The method checkIfCustomerNameAvailable checks if a customer name is available in customer table.
	 * @param customer
	 * @return true or false.
	 * @throws CouponSystemException -in case of SQL Exception
	 */
	boolean checkIfCustomerNameAvailable (Customer customer) throws CouponSystemException;

	/**
	 * The method getCustomer retrieves a customer details from the customer table.
	 * @param id
	 * @return the customer by id or null if not found.
	 * @throws CouponSystemException -in case of SQL Exception
	 */
	Customer getCustomer(long id) throws CouponSystemException;

	/**
	 * The method getAllCustomer retrieves a collection of all customer from the customer table.
	 * @return collection of customers or null
	 * @throws CouponSystemException -in case of SQL Exception
	 */
	Collection<Customer> getAllCustomer() throws CouponSystemException;

	/**
	 * The method login checks if the name and password matches the information in the customer table
	 * @param name
	 * @param password
	 * @return  if login is successful: loginSuccessful= true , id=customer id.
	 * if failed will return: loginSuccessful= false,id=-1
	 * @throws CouponSystemException -in case of SQL Exception
	 */
	LoginDetails login(String name, String password) throws CouponSystemException;

}
