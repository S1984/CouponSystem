package test;

import core.Facade.AdminFacade;
import core.beans.ClientType;
import core.beans.Company;
import core.beans.Customer;
import core.exceptions.CouponSystemException;
import system.CouponSystem;

public class TestAdmin {

	public static void main(String[] args) {
		CouponSystem system = null;
		AdminFacade adminFacade = null;
		try {
			system = CouponSystem.getInstance();
			adminFacade = (AdminFacade) system.login("admin", "1234", ClientType.ADMINISTRATOR);
			Company comp10 = new Company(1010, "comp10Name", "comp10Pass", "comp10Email");
			Customer cust50 = new Customer(5050, "cust50Name", "cust50pass");

			adminFacade.createCompany(comp10);
			adminFacade.createCustomer(cust50);
			System.out.println("admin created customer and company");
			System.out.println(adminFacade.getCompany(comp10.getId()));
			System.out.println(adminFacade.getCustomer(cust50.getId()));
			System.out.println("=================================");

			comp10.setPassword("pass1234");
			cust50.setPassword("pass1234");
			adminFacade.updateCompany(comp10);
			adminFacade.updateCustomer(cust50);
			System.out.println("admin update customer and company");
			System.out.println(adminFacade.getCompany(comp10.getId()));
			System.out.println(adminFacade.getCustomer(cust50.getId()));
			System.out.println("=================================");

			adminFacade.removeCompany(comp10);
			adminFacade.removeCustomer(cust50);
			System.out.println("admin remove customer and company");
			try {
				System.out.println(adminFacade.getCompany(comp10.getId()));
			} catch (CouponSystemException e) {
				System.out.println(e.getMessage());
			}
			try {
				System.out.println(adminFacade.getCustomer(cust50.getId()));
			} catch (CouponSystemException e) {
				System.out.println(e.getMessage());
			}
			System.out.println("=================================");
			
			System.out.println(adminFacade.getAllCompanies());
			System.out.println(adminFacade.getAllCustomer());

		} catch (CouponSystemException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				system.shutDown();
			} catch (CouponSystemException e) {
				e.printStackTrace();
			}

		}
	}

}
