package core.dao;

import java.util.Collection;

import core.beans.Company;
import core.beans.LoginDetails;
import core.exceptions.CouponSystemException;

public interface CompanyDAO {
	
	/**
	 * The method createCompany  creates anew coupon in the company table.
	 * @param company
	 * @throws CouponSystemException - in case of SQL Exception or duplicate unique name or id
	 */
	void createCompany(Company company) throws CouponSystemException;

	/**
	 * the method removeCompany removes a company from the table company 
	 * @param company
	 * @throws CouponSystemException -in case of SQL Exception.
	 */
	void removeCompany(Company company) throws CouponSystemException;

	/**
	 * The method updateCompany updates all details of the company in company table.
	 * @param company
	 * @throws CouponSystemException -in case of SQL Exception or duplicate unique name or id
	 */
	void updateCompany(Company company) throws CouponSystemException;

	/**
	 * The method getComapny retrieves company details according to company id 
	 * @param id
	 * @return the company by id or null if not found.
	 * @throws CouponSystemException -in case of SQL Exception.
	 */
	Company getCompany(long id) throws CouponSystemException;

	/**
	 * the method getAllCompanies  retrieves a collection of all companies from the company table. 
	 * @return collection of companies or null
	 * @throws CouponSystemException in case of SQL Exception or duplicate
	 */
	Collection<Company> getAllCompanies() throws CouponSystemException;

	
	/**
	 * The method login checks if the name and password matches the information in the company table
	 * @param name
	 * @param password
	 * @return  if login is successful: loginSuccessful= true , id=company id.
	 * if failed will return: loginSuccessful= false,id=-1
  
	 * @throws CouponSystemException -in case of SQL Exception or duplicate
	 */
	LoginDetails login(String name, String password) throws CouponSystemException;

	/**
	 * The method checkIfCompanyNameAvailable checks the if the company name already exist in company table 
	 * @param company
	 * @return true or false
	 * @throws CouponSystemException -in case of SQL Exception or duplicate
	 */
	boolean checkIfCompanyNameAvailable (Company company) throws CouponSystemException;

}
