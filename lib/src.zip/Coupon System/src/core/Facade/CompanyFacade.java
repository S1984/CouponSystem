package core.Facade;

import java.util.Collection;
import java.util.Date;

import core.beans.*;
import core.dao.*;
import core.dao.db.CompanyCouponDBDAO;
import core.dao.db.CouponDBDAO;
import core.dao.db.CustomerCouponDBDAO;
import core.exceptions.CouponSystemException;
import core.exceptions.FacadeException;

public class CompanyFacade extends CouponClientFacade {

	private CouponDAO coupondbdao;
	private CompanyCouponDAO companycoupondbdao;
	private CustomerCouponDAO customercoupondbdao;//added at 01/09/2017, after received feedback from Eldar
	private Company company;

	public CompanyFacade(Company company) throws CouponSystemException {
		this.company = company;
		coupondbdao = new CouponDBDAO();
		companycoupondbdao = new CompanyCouponDBDAO();
		customercoupondbdao = new CustomerCouponDBDAO();//added at 01/09/2017, after received feedback from Eldar
	}

	/**
	 * The method createCoupon adds a coupon to the coupon table and checks if
	 * there is already a coupon with the same title.
	 * 
	 * @param coupon
	 *            - the coupon we are adding.
	 * @throws CouponSystemException
	 *             - from DBDAO.
	 */
	public void createCoupon(Coupon coupon) throws CouponSystemException {
		coupondbdao.createCoupon(coupon);
		companycoupondbdao.insertCoupon(this.company, coupon);
	}

	public void removeCoupon(Coupon coupon) throws CouponSystemException {
		if (!companycoupondbdao.checkIfCouponBelongToCompany(company, coupon)) {
			FacadeException facadeexception = new FacadeException(
					"removeCoupon in CompanyFacade  not executed, because the coupon does not bilong to your company or not exists");
			throw facadeexception;
		}
		
		coupondbdao.removeCoupon(coupon);
		companycoupondbdao.removeCoupon(coupon);
		customercoupondbdao.removeCoupon(coupon);//added at 01/09/2017, after received feedback from Eldar
	}

	/**
	 * The method updateCoupon updates the end date and price of a coupon in the
	 * coupon table.
	 * 
	 * @param coupon
	 *            - the coupon to update in the DB
	 * @throws CouponSystemException
	 *             from DAODB.
	 * @throws FacadeException
	 *             if the coupon id dose not exists.
	 */
	public void updateCoupon(Coupon coupon) throws CouponSystemException {
		if (!companycoupondbdao.checkIfCouponBelongToCompany(company, coupon)) {
			FacadeException facadeexception = new FacadeException(
					"updateCoupon in CompanyFacade  not executed, because the coupon does not bilong to your company or not exists");
			throw facadeexception;
		}//added at 01/09/2017, after received feedback from Eldar 
		
		Coupon couponFromDB = coupondbdao.getCoupon(coupon.getId());
		if (couponFromDB == null) {
			FacadeException facadeexception = new FacadeException(
					"updateCoupon in company facade Failed, coupon id dose not exists");
			throw facadeexception;
		}
		couponFromDB.setEndDate(coupon.getEndDate());
		couponFromDB.setPrice(coupon.getPrice());
		coupondbdao.updateCoupon(couponFromDB);
	}

	/**
	 * The method getCoupon retrieves a coupons details by checking coupon id.
	 * 
	 * @param id
	 *            - the id of the coupon we are looking for.
	 * @return requested coupon by id
	 * @throws CouponSystemException
	 *             - from DAODB.
	 */
	public Coupon getCoupon(long id) throws CouponSystemException {
		
		Coupon couponFromDB = coupondbdao.getCoupon(id);
		if (couponFromDB == null) {
			FacadeException facadeexception = new FacadeException(
					"getCoupon in Company facade Failed , coupon id does not exist");
			throw facadeexception;
		}
		return couponFromDB;
	}
	
/**
 *  the method getAllCoupons retrieves a collection of all the coupons of a certain company in the coupon table
 * @return collection of all company coupons
 * @throws CouponSystemException - from DAODB.
 */
	public Collection<Coupon> getAllCoupons() throws CouponSystemException {
		return coupondbdao.getCouponByCompany(this.company);

	}
/**
 * The method getCouponsByType retries a collection of all the  coupons of a certain company by requested type.
 * @param coupontype
 * @return coupon by company and by type
 * @throws CouponSystemException - from DAODB
 */
	public Collection<Coupon> getCouponByType(CouponType coupontype) throws CouponSystemException {
		return coupondbdao.getCouponByCompanyAndType(company, coupontype);

	}
/**
 * The method getCouponsByPriceLimit retrieves a collection of all the coupons of a certain company with a limit price.
 * @param price
 * @return coupon by company and price limit.
 * @throws CouponSystemException  - from DAODB
 */
	public Collection<Coupon> getCouponByPriceLimit(double price) throws CouponSystemException {
		return coupondbdao.getCouponByCompanyAndPriceLimit(company, price);

	}
/**
 * The method getCouponByDateLimit retrieves a collection of all the coupons of a certain company 
 * @param dateLimit
 * @return coupons  by company and by date limit
 * @throws CouponSystemException - from DAODB
 */
	public Collection<Coupon> getCouponByDateLimit(Date dateLimit) throws CouponSystemException {
		return coupondbdao.getCouponByCompanyAndDateLimit(company, dateLimit);

	}
	// add 30.09 for welcome page 
	public String getCompanyName (){
		return this.company.getName();
	}

}
