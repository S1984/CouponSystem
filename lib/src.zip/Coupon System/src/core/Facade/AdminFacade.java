package core.Facade;

import java.util.Collection;
import core.beans.*;
import core.dao.CompanyCouponDAO;
import core.dao.CompanyDAO;
import core.dao.CouponDAO;
import core.dao.CustomerCouponDAO;
import core.dao.CustomerDAO;
import core.dao.db.*;
import core.exceptions.CouponSystemException;
import core.exceptions.FacadeException;

public class AdminFacade extends CouponClientFacade {

	private CompanyDAO companydbdao;
	private CustomerDAO customerdbdao;
	private CouponDAO coupondbdao;
	private CompanyCouponDAO companycoupondbdao;
	private CustomerCouponDAO customercoupondbdao;

	public AdminFacade() throws CouponSystemException {
		companydbdao = new CompanyDBDAO();
		customerdbdao = new CustomerDBDAO();
		coupondbdao = new CouponDBDAO();
		companycoupondbdao = new CompanyCouponDBDAO();
		customercoupondbdao = new CustomerCouponDBDAO();
	}

	/**
	 * The Method creates a new company in the system and checks if the
	 * company's name is available.
	 * 
	 * @param company
	 *            - the company to create.
	 * @throws CouponSystemException
	 *             - from DBDAO.
	 * @throws facadeexception
	 *             - if name or id is not unique.
	 */
	public void createCompany(Company company) throws CouponSystemException {
		FacadeException facadeexception = null;
		if (!(companydbdao.checkIfCompanyNameAvailable(company))) {
			facadeexception = new FacadeException(
					"createCompany in Admin facade canceled ,company name has to be unique: " + company.getName());
			throw facadeexception;
		}
		if (companydbdao.getCompany(company.getId()) != null) {
			facadeexception = new FacadeException(
					"createCompany in Admin facade canceled ,company ID has to be unique: " + company.getId());
			throw facadeexception;
		}
		companydbdao.createCompany(company);
	}

	/**
	 * this method deletes the company and all of its coupons the method
	 * "execute DAODBgetCouponByCompany" checks all of the coupons and deletes
	 * them one by one from coupon table and from customer_coupon table.
	 * "execute DAODBremoveAllCompanyCoupons" delete all coupons of specific
	 * company from company coupon table.
	 * 
	 * @param company
	 *            - the company to remove from the DB
	 * @throws CouponSystemException
	 *             from DBDAO
	 * @throws FacadeException
	 *             if the company does not exist.
	 */
	public void removeCompany(Company company) throws CouponSystemException {
		try {
			this.getCompany(company.getId());
		} catch (FacadeException fe) {
			FacadeException facadeexception = new FacadeException(
					"removeCompany in Admin facade Failed: id does not exist");
			throw facadeexception;
		}
		Collection<Coupon> companyCoupons = coupondbdao.getCouponByCompany(company);
		companydbdao.removeCompany(company);
		companycoupondbdao.removeAllCompanyCoupons(company);
		if (companyCoupons != null) {
			for (Coupon coupon : companyCoupons) {
				coupondbdao.removeCoupon(coupon);
				customercoupondbdao.removeCoupon(coupon);
			}
		}
	}

	/**
	 * Update company this method updates email and password in company table ,
	 * 
	 * @param company
	 *            company to update in the DB.
	 * @throws CouponSystemException
	 *             from DBDAO.
	 * @throws FacadeException
	 *             if company does not exist.
	 */
	public void updateCompany(Company company) throws CouponSystemException {
		Company companyFromDB = null;
		try {
			companyFromDB = this.getCompany(company.getId());
		} catch (FacadeException fe) {
			FacadeException facadeexception = new FacadeException(
					" updateCompany in Admin facade Failed , company id  does not exist");
			throw facadeexception;
		}
		companyFromDB.setEmail(company.getEmail());
		companyFromDB.setPassword(company.getPassword());
		companydbdao.updateCompany(companyFromDB);
	}

	/**
	 * getCompany this method retrieves a company's details according to the
	 * company id
	 * 
	 * @param id
	 *            of the company we wish to get details about.
	 * @return requested company by id
	 * @throws CouponSystemException
	 *             from DBDAO.
	 * @throws FacadeException
	 *             if company id does not exist
	 */
	public Company getCompany(long id) throws CouponSystemException {
		Company companyFromDB = companydbdao.getCompany(id);
		if (companyFromDB == null) {
			FacadeException facadeexception = new FacadeException(
					"getCompany in Admin facade Failed , company id does not exist");
			throw facadeexception;
		}
		return companyFromDB;
	}

	/**
	 * getAllCompanies method returns a collection of all comanies in the
	 * company table.
	 * 
	 * @return Collection of all companies in the system, if there is no company
	 *         returns null
	 * @throws CouponSystemException
	 *             from DBDAO.
	 */
	public Collection<Company> getAllCompanies() throws CouponSystemException {
		return companydbdao.getAllCompanies();
	}

	/**
	 * createCustomer method creates a new customer in the system and checks if
	 * the customer's name already exist in the system.
	 * 
	 * @param customer
	 *            - the customer to create.
	 * @throws CouponSystemException
	 *             from DBDAO.
	 * @throws facadeexception
	 *             if name or id is not unique.
	 */
	public void createCustomer(Customer customer) throws CouponSystemException {
		FacadeException facadeexception = null;
		if (!(customerdbdao.checkIfCustomerNameAvailable(customer))) {
			facadeexception = new FacadeException(
					"createCustomer in Admin facade canceled ,customer name has to be unique: " + customer.getName());
			throw facadeexception;
		}
		if (customerdbdao.getCustomer(customer.getId()) != null) {
			facadeexception = new FacadeException(
					"createCustomer in Admin facade canceled ,customer ID has to be unique: " + customer.getId());
			throw facadeexception;
		}
		customerdbdao.createCustomer(customer);
	}

	/**
	 * removeCustomer method deletes the customer and all of his coupons
	 * "execute DAODBremoveCustomer" deletes the customer from customer table. "
	 * execute DAODBremoveCustomerCoupons" deletes all customer coupons from
	 * customer coupons table.
	 * 
	 * @param customer
	 *            customer to remove from the DB.
	 * @throws CouponSystemException
	 *             from DBDAO.
	 * @throws FacadeException
	 *             if customer does not exist.
	 */
	public void removeCustomer(Customer customer) throws CouponSystemException {
		try {
			getCustomer(customer.getId());
		} catch (FacadeException fe) {
			FacadeException facadeexception = new FacadeException(
					"removeCustomer in Admin facade Failed , Customer id not exist");
			throw facadeexception;
		}
		customerdbdao.removeCustomer(customer);
		customercoupondbdao.removeCustomerCoupons(customer);

	}

	/**
	 * the method update customer password gets the customer by id and updates
	 * the customers password.
	 * 
	 * @param customer
	 *            customer to update in the DB
	 * @throws CouponSystemException
	 *             from DBDAO.
	 * @throws FacadeException
	 *             if id does not exist
	 */
	public void updateCustomer(Customer customer) throws CouponSystemException {
		Customer customerFromDB = null;
		try {
			customerFromDB = getCustomer(customer.getId());
		} catch (FacadeException fe) {
			FacadeException facadeexception = new FacadeException(
					"updateCustomer in Admin facade Failed , Customer id not exist");
			throw facadeexception;
		}
		customerFromDB.setPassword(customer.getPassword());
		customerdbdao.updateCustomer(customerFromDB);
	}

	/**
	 * The method getCustomer retrieves customers details from the customer table by using the customer id
	 * @param id
	 *            of customer we are requesting.
	 * @return requested customer by id.
	 * @throws CouponSystemException
	 *             from DBDAO.
	 * @throws FacadeException
	 *             if customer id does not exist.
	 */
	public Customer getCustomer(long id) throws CouponSystemException {
		Customer customerFromDB = customerdbdao.getCustomer(id);
		if (customerFromDB == null) {
			FacadeException facadeexception = new FacadeException(
					"getCustomer in Admin facade Failed , customer id not exist");
			throw facadeexception;
		}
		return customerFromDB;
	}

	/**
	 * the method getAllCustomer returns a collection of all the customers in customer table.
	 * @return Collection of all customers in the system, if there is no
	 *         customer returns null
	 * @throws CouponSystemException
	 *             from DBDAO.
	 */
	public Collection<Customer> getAllCustomer() throws CouponSystemException {
		return customerdbdao.getAllCustomer();
	}

}
