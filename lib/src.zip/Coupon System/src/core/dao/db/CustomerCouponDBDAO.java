package core.dao.db;


import core.beans.Coupon;
import core.beans.Customer;
import core.dao.CustomerCouponDAO;
import core.exceptions.CouponSystemException;

public class CustomerCouponDBDAO implements CustomerCouponDAO {


	public CustomerCouponDBDAO() {
	}
	/**
	 *  The removeCoupon method  gets instance of Coupon.bean and deletes the coupon from Customer_Coupon table in case it fails to remove a coupon, 
	 *   it will Throw a  CouponSystemException. 
	 */
	@Override
	public void removeCoupon(Coupon coupon) throws CouponSystemException {
		String sql = "DELETE FROM Customer_Coupon WHERE coupon_id=" + coupon.getId();
		String failedMessage = "removeCoupon Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);
	
	}
	/**
	 *  The removeCustomerCoupons method  gets instance of Customer.bean and deletes the coupon from Customer_Coupon table in case it fails to remove a coupon, 
	 *   it will Throw a  CouponSystemException. 
	 */
	@Override
	public void removeCustomerCoupons(Customer customer) throws CouponSystemException {
		String sql = "DELETE FROM Customer_Coupon WHERE Customer_id=" + customer.getId();
		String failedMessage = "removeCustomerCoupons Failed: ";
		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);
		
	}
	/**
	 * The addCustomerCoupon method adds a instance of coupon.bean and updates its values (customer_id,coupon _id) in case it fails to update the details, it will throw a CouponSystemException.  
	 */
	@Override
	public void addCustomerCoupon(Customer customer, Coupon coupon) throws CouponSystemException {
		String sql = "INSERT INTO Customer_Coupon VALUES(" + customer.getId() + ", " + coupon.getId() + ")";
		String failedMessage = "addCustomerCoupon Failed: ";

		SqlCommand.executeUpdateOneErorMessage(sql, failedMessage);		
	}
	/**
	 * the checkIfCouponAlreadyAdded method  checks  if the combination of  customer_id and  coupon id 
	 * if there is no existing coupon with the stated customer_id it will return true. 
	 * in case there is already a coupon with the same customer_id it will return false. 
	 * In case of failure it will throw CouponSystemException 
	 */
	@Override
	public boolean checkIfCouponAlreadyAdded(Customer customer, Coupon coupon) throws CouponSystemException {
		String sql = "SELECT * from Customer_Coupon WHERE customer_id= " + customer.getId() + " AND coupon_id= "+coupon.getId();
		String failedMessage = "checkIfCouponAlreadyAdded Failed: ";
		if(null==SqlCommand.executeQueryOneErorMessage(sql, failedMessage))
			return false;
		else
			return true;
	}

}
