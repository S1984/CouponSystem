package db.pool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import db.build.DbDriverAndUrl;

public class ConnectionPool {

	private Set<Connection> connections = new HashSet<>();
	// we need to hold the link to all connections for future closing.
	private Set<Connection> AllConnectionsSaved = new HashSet<>();
	private String url;
	private String driverName;
	private static ConnectionPool instance = null;
	

	private ConnectionPool() throws  SQLException {
		 driverName = DbDriverAndUrl.getInstance().getDriverName();
		 url = DbDriverAndUrl.getInstance().getUrl();
		try {
			Class.forName(driverName);

		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
		for (int i = 0; i < 10; i++) {
			Connection con = DriverManager.getConnection(url);
			connections.add(con);
			AllConnectionsSaved.add(con);
		}
		
	}
	/**
	 * The method getInstance returns a signaltone of  if its not the first time it will return instance of an object if it is the first time it creates a new instance. 
	 * @return instance if exists if not it creates a new one.
	 * @throws SQLException
	 */
	public static ConnectionPool getInstance() throws SQLException {
		if (instance == null) {
			instance = new ConnectionPool();
		}
		return instance;
	}
	
	/** 
	 * The method getConnection gets a connection from the connection pool.
	 * @return connection.
	 */
	public synchronized Connection getConnection() {
		while (connections.isEmpty()) {
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
				
			}
		}
		Iterator<Connection> it = connections.iterator();
		Connection con = it.next();
		it.remove();
		return con;
	}

	/**
	 * The method returnCon returns the connection to the connection pool.
	 * @param con
	 */
	public synchronized void returnCon(Connection con) {
		connections.add(con);
		notify();
	}
	/**
	 * The method closeAllConnections closes all the connections.
	 * @throws SQLException
	 */
	public synchronized void closeAllConnections() throws SQLException{
		for (Connection connection : AllConnectionsSaved) {
			connection.close();
		}
		
		
	}

}
