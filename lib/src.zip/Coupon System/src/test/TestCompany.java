package test;

import java.util.Calendar;
import java.util.Date;

import core.Facade.AdminFacade;
import core.Facade.CompanyFacade;
import core.beans.ClientType;
import core.beans.Company;
import core.beans.Coupon;
import core.beans.CouponType;
import core.exceptions.CouponSystemException;
import system.CouponSystem;

public class TestCompany {

	public static void main(String[] args) {
		CouponSystem system = null;
		
		Calendar cal = Calendar.getInstance();
		Date startDate = cal.getTime();
		cal.set(2018, Calendar.JANUARY, 20, 0, 0, 0);
		Date endDate1 = cal.getTime();
		cal.set(2018, Calendar.FEBRUARY, 20, 0, 0, 0);
		Date endDate2 = cal.getTime();

		Coupon coupon1 = new Coupon(1, "BelongToComp11", startDate, endDate1, 2, CouponType.FOOD, "bilong to comp11", 200,"no iamge");
		Coupon coupon2 = new Coupon(2, "BelongToComp11", startDate, endDate2, 2, CouponType.SPORTS, "bilong to comp11", 300,"no iamge");
		try {
			system = CouponSystem.getInstance();
			AdminFacade adminFacade = (AdminFacade) system.login("admin", "1234", ClientType.ADMINISTRATOR);
			Company comp10 = new Company(1010, "comp10Name", "comp10Pass", "comp10Email");
			adminFacade.createCompany(comp10);
			CompanyFacade companyFacade = (CompanyFacade) system.login(comp10.getName(), comp10.getPassword(), ClientType.COMPANY);
			
			companyFacade.createCoupon(coupon1);
			companyFacade.createCoupon(coupon2);
			System.out.println("comp10 successful add 2 coupon");
			System.out.println(companyFacade.getAllCoupons());
			System.out.println("=======================");

			System.out.println("show all coupons under 250$");
			System.out.println(companyFacade.getCouponByPriceLimit(250));
			System.out.println("=======================");

			System.out.println("show all coupons from food type");
			System.out.println(companyFacade.getCouponByType(CouponType.FOOD));
			System.out.println("=======================");

			coupon2.setPrice(150);
			companyFacade.updateCoupon(coupon2);
			System.out.println("show all coupons under 250$, after update coupon2 price ");
			System.out.println(companyFacade.getCouponByPriceLimit(250));
			System.out.println("=======================");
			
			
			System.out.println("show all coupons before : "+endDate1);
			companyFacade.getCouponByDateLimit(endDate1);
			System.out.println("=======================");

			System.out.println("remove coupon2");
			
			companyFacade.removeCoupon(coupon2);
			try {
				System.out.println(companyFacade.getCoupon(coupon2.getId()));
			} catch (CouponSystemException e) {
				System.out.println(e.getMessage());
			}
			System.out.println("=======================");
			
			adminFacade.removeCompany(comp10);
			
			
			
		} catch (CouponSystemException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				system.shutDown();
			} catch (CouponSystemException e) {
				e.printStackTrace();
			}
		}
	}
}
