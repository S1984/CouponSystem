package core.dao;

import core.beans.Coupon;
import core.beans.Customer;
import core.exceptions.CouponSystemException;

public interface CustomerCouponDAO {

	/**
	 * The method removeCoupon removes coupon from Customer_coupon table
	 * @param coupon
	 * @throws CouponSystemException -in case of SQL Exception
	 */
	void removeCoupon(Coupon coupon) throws CouponSystemException;

	/**
	 * The method removeCustomerCoupons removes all  customer coupons from the table Customer_coupon
	 * @param customer
	 * @throws CouponSystemException -in case of SQL Exception
	 */
	void removeCustomerCoupons(Customer customer) throws CouponSystemException;

	/**
	 * The method addCustomerCoupon adds a coupon_id and customer_id  to the customer _coupon table
	 * @param customer
	 * @param coupon
	 * @throws CouponSystemException -in case of SQL Exception
	 */
	void addCustomerCoupon(Customer customer, Coupon coupon) throws CouponSystemException;
	
	/**
	 * The method checkIfCouponAlreadyAddedchecks if a coupon already exists in Customer_coupon table.
	 * @param customer
	 * @param coupon
	 * @return true or false 
	 * @throws CouponSystemException -in case of SQL Exception
	 */
	boolean checkIfCouponAlreadyAdded (Customer customer, Coupon coupon) throws CouponSystemException;
}
