package core.thread;

import java.util.Collection;
import java.util.Date;

import core.beans.Coupon;
import core.dao.db.CompanyCouponDBDAO;
import core.dao.db.CouponDBDAO;
import core.dao.db.CustomerCouponDBDAO;
import core.exceptions.CouponSystemException;

public class DailyCouponExpirationTask implements Runnable {

	private long timeToSleep = 1000 * 60 * 60 * 24;
	private CouponDBDAO coupondbdao;
	private CompanyCouponDBDAO companycoupondbdao;
	private CustomerCouponDBDAO customercoupondbdao;
	//private Thread pointerToThisthread; bad! really bad!
	private boolean notStop = true;

	
	public DailyCouponExpirationTask() throws CouponSystemException {
		
		coupondbdao = new CouponDBDAO();
		companycoupondbdao = new CompanyCouponDBDAO();
		customercoupondbdao = new CustomerCouponDBDAO();
		
	}


	@Override
	public void run() {
		//pointerToThisthread = Thread.currentThread();
		while (notStop) {
			this.dailyTask();
			System.out.println("Message from DailyCouponExpirationTask: finished  dailyTask, going to sleep for 24h");
			try {
				Thread.sleep(timeToSleep);
			} catch (InterruptedException e) {
				System.out.println("InterruptedException" + e.getMessage());
				break;
			}
		}
	}

	private void dailyTask() {
		Date now = new Date();
		Collection<Coupon> expiredCoupons = null;
		try {
			expiredCoupons = coupondbdao.getCouponByDateLimit(now);
		} catch (CouponSystemException e) {
			System.out.println("Failed to get collection of  expired coupons from DB, " + e.getMessage());
		}
		if (expiredCoupons != null) {
			for (Coupon coupon : expiredCoupons) {

				try {
					coupondbdao.removeCoupon(coupon);
					companycoupondbdao.removeCoupon(coupon);
					customercoupondbdao.removeCoupon(coupon);
					System.out.println("Message from DailyCouponExpirationTask: this coupon is outdated  ID= "+coupon.getId()+" and was removed successfully");
				} catch (CouponSystemException e) {
					System.out.println("Failed to remove expired coupon, couponID: " + coupon.getId() + ", from DB, "
							+ e.getMessage());
				}
			}

		}
	}

	/**
	 * the method StopTheTask stops the daily coupon expiration task.
	 * 
	 */
	public void StopTheTask() {
		this.notStop = false; 	
//		try {
//			pointerToThisthread.join();
//		} catch (InterruptedException e) {
//			System.out.println(e.getMessage());
//		}
		
	}
}
